#include "register.h"

void personalPrint(Person* input);