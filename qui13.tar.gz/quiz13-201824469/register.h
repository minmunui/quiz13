#ifndef _REGISTER
#define _REGISTER

#include <stdio.h>
#include <stdlib.h>
#define TEXT_FILE "./phonebook.txt"

struct Person {
  char name[20];
  char phoneNumber[20];
  struct Person* next;
};

typedef struct Person Person;

extern Person* p, *head, *tail;

void newRegister();

void overrideFile(Person* headPerson, const char* fileName);

void uploadPerson(Person* personToUpload, const char* fileName);

#endif