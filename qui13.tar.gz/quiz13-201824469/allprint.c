#include "allprint.h"

void printAllPeople(){
  printf("<< Phone Number List >>\n");
  Person* cursor = head;
  while (cursor!=NULL) {
    personalPrint(cursor);
    cursor = cursor->next;
  }
}