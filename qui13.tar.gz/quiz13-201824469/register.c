#include "register.h"

void newRegister() {
  printf("Name: ");
  scanf("%s", p->name);

  printf("Phone Num: ");
  scanf("%s", p->phoneNumber);
  printf("%s is registered!\n", p->name);
  uploadPerson(p, TEXT_FILE);
  p->next = NULL;
  if (head==NULL) {
    head = p;
  }
  else {
    tail->next = p;
  }
  tail = p;
  p = (Person*) malloc(sizeof(Person));
}

void overrideFile(Person* headPerson, const char* fileName) {
  FILE* upload = fopen(fileName, "w");
  while( headPerson!=NULL ){
    fprintf(upload, "%s %s\n", headPerson->name, headPerson->phoneNumber);
    headPerson = headPerson->next;
  }
  fclose( upload );
}

void uploadPerson(Person* personToUpload, const char* fileName) {
  FILE* upload = fopen(fileName, "a");
  fprintf(upload, "%s %s\n", personToUpload->name, personToUpload->phoneNumber);
  fclose(upload);
}