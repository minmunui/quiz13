#include "register.h"
#include "personalprint.h"

void printAllPeople();