#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "register.h"
#include "personalprint.h"
#include "allprint.h"

enum Command{ REGISTER=1, PRINT_ALL, SEARCH_SPECIFIC, DELETION, EXIT, INVALID};
enum LoginResult{ FAIL = 0, SUCCESS = 1, TRYING = 2};

Person* p, *head=NULL, *tail=NULL;

int login(); //identify password. return fail=0 SUCCESS = 1

void downloadPeople(const char* fileName) {
  FILE *download = fopen(fileName, "r");
  if (download != NULL) {
    while (fscanf(download, "%s %s\n", p->name, p->phoneNumber) == 2) {
      p->next = NULL;
      if (head == NULL) {
        head = p;
      } else {
        tail->next = p;
      }
      tail = p;
      p = (Person *) malloc(sizeof(Person));
    }
  }
}
Person* searchSpecific() {
  Person* result = NULL;
  char inputName[20];
  printf("Search: ");
  scanf("%s", inputName);
  Person* cursor = head;
  while(cursor!=NULL) {
    if ( strcmp(cursor->name, inputName) == 0) {
      result = cursor;
    }
    cursor = cursor->next;
  }
  return result;
}

void deletePerson(Person* personToDelete) {
  printf("Deletion: %s\n", personToDelete->name);
  if( personToDelete == head) {
    head = personToDelete->next;
    free(personToDelete);
  }
  else {
    Person *cursor = head;
    while (cursor->next != personToDelete) {
      cursor = cursor->next;
    }
    if (personToDelete == tail) {
      tail = cursor;
    }
    cursor->next = personToDelete->next;
    free(personToDelete);
  }
}

int main(void) {
  p = malloc(sizeof(Person));
  int service = INVALID;
  downloadPeople(TEXT_FILE);
  do {
    printf("1. Registration    2. Total List    3. Search    4. Deletion    5. Exit\n");
    printf("Select Menu:");
    scanf("%d", &service);
    if( service < 1 || service > 5) {
      service = INVALID;
    }
    switch (service) {
      case REGISTER: {
        if ( login()==FAIL ) {
          service = EXIT;
        } else {
          newRegister();
        }
        break;
      }
      case PRINT_ALL: {
        printAllPeople();
        break;
      }
      case SEARCH_SPECIFIC: {
        Person* indexFound;
        indexFound = searchSpecific();
        if ( indexFound != NULL ) {
          personalPrint(indexFound);
        }
        else {
          printf("No search result found.\n");
        }
        break;

      }
      case DELETION: {
        Person* personFound;
        personFound = searchSpecific();
        if ( personFound != NULL ) {
          deletePerson(personFound);
        }
        else {
          printf("No search result found.\n");
        }
        overrideFile( head ,TEXT_FILE);
        break;
      }
      case EXIT: {
        break;
      }
      case INVALID: {
        break;
      }
      default: {};
    }
  } while (service != EXIT);
  printf("The Phonebook manager is terminated!\n");
  overrideFile( head, TEXT_FILE );
  return 0;
}

int login() { //identify password. return fail=0 SUCCESS = 1

  const char PASSWORD[20] = "qwer1234";
  const int MAXTRIAL = 3;

  static int loginTrial;
  int loginResult = TRYING;
  char inputPassword[20];
  do {
    switch (loginTrial)
    {
      case 0:
        break;
      case 1:
        printf("1st Incorrect password!\n");
        break;
      case 2:
        printf("2nd Incorrect password!\n");
        break;
      case 3:
        printf("3nd Incorrect password!\n");
        printf("You cannot register new phone number.\n");
        return FAIL;
      default:
        break;
    }
    printf("Password: ");
    scanf("%s", inputPassword);
    if ( strcmp(inputPassword, PASSWORD) == 0 ) {
      loginResult = SUCCESS;
      loginTrial = 0;
    }
    else { loginTrial ++; }
  } while (loginResult == TRYING);
  return loginResult;
}