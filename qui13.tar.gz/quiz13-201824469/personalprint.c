#include "personalprint.h"

void personalPrint(Person* input){
  printf("%s\t%s\n", input->name, input->phoneNumber);
}